export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDC0o0x8lNQDcSXC00x734TNesD-m1Ws_k",
    authDomain: "oshop-ded15.firebaseapp.com",
    databaseURL: "https://oshop-ded15.firebaseio.com",
    projectId: "oshop-ded15",
    storageBucket: "",
    messagingSenderId: "263486942708",
    appId: "1:263486942708:web:dd720c790f2ae7a7"
  }
};
